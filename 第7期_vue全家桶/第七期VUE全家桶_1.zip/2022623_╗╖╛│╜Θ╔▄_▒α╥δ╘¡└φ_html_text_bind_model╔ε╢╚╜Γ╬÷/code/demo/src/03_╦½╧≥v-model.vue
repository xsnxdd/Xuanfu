<template>
    <div>
        <input type="text" v-model="val">
        {{ val }}
        <!-- v-model = v-bind:value input事件通知改变 -->
        <input type="text" v-model="form.username">
    </div>
</template>

<script>
export default {
    data(){
        return {
            val:'123',
            form:{
                username:'Green'
            }
        }   
    }
}
</script>

<style>

</style>