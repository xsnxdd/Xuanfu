<template>
    <div>
        <input type="text" v-bind:value="val"   />
        <input type="text" :value="val"   />
        <!-- 花式玩法:可以多个属性传递 -->
        <input type="text" v-bind="obj"   />
        {{ val }}
        <button @click="val = '123' ">改变val</button>
    </div>
</template>

<script>
export default {
    // v-bind 是单向数据绑定: js改变影响页面
    // 加上页面改变影响内存才是双向数据绑定
    data(){
        return {
            val:'Green',
            obj:{
                value:'xxxx',
                abc:'123',
                ddd:111,
                hhh:111
            }
        }
    }
}
</script>

<style>

</style>