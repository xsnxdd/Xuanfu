<template>
  <div class="box">
    <h2>{{text}}</h2>
    <h2 v-text="text"></h2>
    <!-- html解析不同于当前的template时机 -->
    <div v-html="myHtml"></div>
  </div>
</template>
<script>


export default {
  name: 'App',
  data(){
    return {
      text:'hello Green',
      myHtml:`<button class="btn">按钮</button>`
    }
  }
}
</script>

<style lang="scss" scoped>
/* 全局样式才生效 */
.btn {
  background: red;
}
.box {
  h2 {
    color:red;
  }
}
</style>
