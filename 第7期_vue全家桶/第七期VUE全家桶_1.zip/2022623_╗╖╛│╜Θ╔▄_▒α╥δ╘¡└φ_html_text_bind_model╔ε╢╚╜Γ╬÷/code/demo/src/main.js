import Vue from 'vue'
import App from './03_双向v-model.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
