export default {
    state:{
        isLogin:false,
        userInfo:null,
        userMenus:null // 用户路由菜单
    },
    getters:{
        getIsLogin(state){
            return state.isLogin
        },
        getUserInfo(state){
            return state.userInfo
        },
    },
    mutations:{
        changeIsLogin(state,payload){
            state.isLogin = payload
        },
        changeUserInfo(state,payload) {
            state.userInfo = payload;
        }
    },
    // 异步的行为放在action里面
}