<template>
  <div id="app">
    <!-- <div v-demo:foo.a.b="message"></div> -->
    <input type="text" v-my-bind:value="str" />
    <button v-my-show="isShow">我显示了</button>
    <h1 v-my-if="isExist">我存在了</h1>

    <hr />
    <button @click="str = 'Green老师长得抽象' ">更新str</button>
    <button @click="isShow = !isShow ">更新isShow</button>
    <button @click="isExist = !isExist ">更新myIf</button>
  </div>
</template>

<script>
function showOperation(element, binding, vnode) {
  if (binding.value) {
    // 显示元素
    element.style.display = "block";
  } else {
    // 隐藏元素
    element.style.display = "none";
  }
}
function ifOperation(element, binding, vnode) {}

let clonedNodeStr = null; // 未来直接还原
let parent = null;

export default {
  data() {
    return {
      message: "Green",
      str: "Green老师真的帅",
      isShow: true,
      isExist: true
    };
  },
  directives: {
    "my-if": {
      inserted(el, binding) {
        parent = el.parentNode;
        clonedNodeStr = el.innerHTML; // 保存自身
      },
      update(el, binding) {
        // 如果binding.value => true 插入元素
        // 如果binding.value => false 删除元素  , 留个<!-- -->
        if (binding.value) { // 加入没有实现
          console.log("parent.innerHTML:", parent.innerHTML);
          parentNode.innerHTML = parent.innerHTML.replace('<!-- -->',clonedNodeStr);
        } else {
          // replace 做替换
          parent.innerHTML = parent.innerHTML.replace(el.innerHTML, "<!-- -->");
        }
      }
    },
    "my-show": {
      inserted: showOperation,
      update: showOperation
    },

    "my-bind": {
      bind(element, binding, vnode) {
        // 设置一个属性
        element.setAttribute(binding.arg, binding.value);
      },
      update(element, binding, vnode) {
        element.setAttribute(binding.arg, binding.value);
      }
    },
    demo: {
      bind: function(el, binding, vnode) {
        var s = JSON.stringify;
        el.innerHTML =
          "name: " +
          s(binding.name) +
          "<br>" +
          "value: " +
          s(binding.value) +
          "<br>" +
          "expression: " +
          s(binding.expression) +
          "<br>" +
          "arg: " +
          s(binding.arg) +
          "<br>" +
          "modifiers: " +
          s(binding.modifiers) +
          "<br>" +
          "vnode keys: " +
          Object.keys(vnode).join(", ");
      }
    }
  }
};
</script>

<style>
</style>