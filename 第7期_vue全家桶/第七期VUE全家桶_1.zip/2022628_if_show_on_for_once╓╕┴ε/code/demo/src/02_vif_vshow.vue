<template>
    <div>
        <!-- v-if会根据值动态插入或者移除元素 -->
        <button v-if="isExists">isExists</button>
        <!-- display:none -->
        <button v-show="isShow">isShow</button>
        <!-- 
            总结: show是是否显示的问题, if是插入或移除的问题
            在项目中多使用if 可以减少元素
            在频繁显示与隐藏的情况下, 可以使用v-show
         -->

    </div>
</template>

<script>
export default {
    data(){
        return {
            isExists:true,
            isShow:true
        }
    }
}
</script>

<style>

</style>