<template>
  <div>
    <div class="d1">{{myText}}</div>
    <!-- innerText属性 -->
    <div v-text="myText"></div>
    <div v-html="myHtml"></div>
  </div>
</template>

<script>
export default {
    data() {
        return {
            myText:'abc',
            // 运行时动态生成的元素, scoped开启后无法添加data-xxxx属性选择器
            myHtml:`
                <button class="btn">innerHTML</button>
            `
        }
    }
}
</script>

<style scoped>
.d1 {
    background: red;
}
/*.btn {  //.btn[data-xxxx]
    background: green;
}*/
</style>

<!--
<style >
.btn { /*全局样式 */
    background: green;
}
</style>
-->

<!--
<style scoped>
/* 原生css方式 */
>>> .btn {
    background: green;
}
</style>
-->

<style lang="scss" scoped>
/* scss: /deep/ :deep() ::v-deep */
::v-deep .btn {
    background: green;
}
</style>

