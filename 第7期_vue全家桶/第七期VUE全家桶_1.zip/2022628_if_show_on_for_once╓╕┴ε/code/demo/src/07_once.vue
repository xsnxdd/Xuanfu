<template>
  <div>
        <div v-once>
            {{ products }}
        </div>


        <button @click="change">变更数据</button>

  </div>
</template>

<script>
export default {
    methods:{
        change(){
            this.products[0].name = '1234'; // v-once 只渲染一次, 不会再次变更
        }
    },
    data(){
        return {
            products:[
                {name:'蚂蚁金融' },
                {name:'阿里妈妈' },
                {name:'淘宝' },
            ]
        }
    }
}
</script>

<style>

</style>