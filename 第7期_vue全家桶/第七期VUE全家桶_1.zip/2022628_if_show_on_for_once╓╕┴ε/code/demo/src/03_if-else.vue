<template>
    <div>
        <button v-if="num === 1">1</button>
        <button v-else-if="num === 2">2</button>
        <button v-else-if="num === 3">3</button>
        <button v-else>其他</button>


    </div>
</template>

<script>
export default {
    data(){
        return {
            num:6
        }
    }
}
</script>

<style>

</style>