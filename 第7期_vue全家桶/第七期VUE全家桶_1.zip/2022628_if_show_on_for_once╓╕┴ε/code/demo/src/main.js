import Vue from 'vue'
import App from './09_my-if.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
