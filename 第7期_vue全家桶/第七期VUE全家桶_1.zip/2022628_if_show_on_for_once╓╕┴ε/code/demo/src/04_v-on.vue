<template>
    <div>
        <button v-show="isShow">isShow</button>

        <button v-on:click="isShow = !isShow">点击测试</button>

        <button v-on:click="change">change点击测试</button>
        <button v-on:click="change('测试')">change点击(传参)</button>
        <button v-on:click="change('测试',$event)">change点击(传事件对象)</button>

        <!-- 简写 -->
        <button @click="change('测试简写',$event)">测试简写</button>

        <!-- 2.5之后 动态绑定事件click mouseover -->
        <button @[action]="change('动态参数的事件',$event)">动态参数的事件</button>
    </div>
</template>

<script>
export default {
    methods:{
        // 以下对应模板使用到的方法名, 也可以在方法中调用方法
        change(){
            console.log(arguments)
        }
    },
    data(){
        return {
            isShow:false,
            action:'mouseover'
        }
    }
}
</script>

<style>

</style>