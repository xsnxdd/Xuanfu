<template>
  <div>
    <button v-for="num in arr" :key="num">{{num}}</button>
    <hr />

<!-- 同级间, 相同的元素,相同的key 会报错 -->
    <div>
      <button
        v-for="(val,key,index) in obj"
        :key="index"
      >val:{{val}}|| key: {{key}} || index:{{index}}</button>
    </div>

    <div>
      <button
        v-for="([key,val],index) in map"
        :key="index"
      > key:{{key}} || val:{{val}} || index:{{index}} </button>
    </div>

        <div>
      <button
        v-for="(val,index) in set"
        :key="index"
      > val:{{val}} || index:{{index}} </button>
    </div>


  </div>
</template>

<script>
export default {
  data() {
    return {
      arr: [1, 2, 3, 4],
      obj: { a: 1, b: 2 },
      map:new Map([['c',3],['d',4]]),
      set:new Set(['e','f','g'])
    };
  }
};
</script>

<style>
</style>