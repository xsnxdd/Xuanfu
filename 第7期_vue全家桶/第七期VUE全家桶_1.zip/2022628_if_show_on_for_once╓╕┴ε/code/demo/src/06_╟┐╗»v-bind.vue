<template>
  <div>
    <button :style="isGreen?'background:green':''">三元控制动态style</button>
    <button :style="{ background:'green'}">动态赋值对象style</button>
    <button :style="isGreen?{ background:'green'}:{}">三元赋值对象style</button>
    <button :style="{ background:'red',color:'white'}">多属性对象style</button>


    <button :class="['big','yg']">数组class方式</button>
    <button :class="{big:!isGreen,yg:isGreen}">数组class方式</button>


  </div>
</template>

<script>
export default {
  data() {
    return {
      isGreen: true,
      clist:['big','yg']
    };
  }
};
</script>

<style>
.big {
    font-size: 20px;
}
.yg {
    background: yellowgreen;
}
</style>