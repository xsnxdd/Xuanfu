<template>
  <div id="app">   
    <HelloWorld msg="abc" :value1="num" @getResult="getResult" />

    <!-- :value="num2" @input=" (val) => num2 = val" -->
    <HelloWorld msg="abc" v-model="num2" />


    <hr/>

    {{ myText }}
    <Test :text.sync="myText"  />




  </div>



</template>

<script>

import HelloWorld from './components/HelloWorld'
import Test from './components/Test'
export default {
  data(){
    return {
      myText:'Green',
      num:28,
      num2:19
    }
  },
  methods:{
    getResult(data){
      console.log('获取到子组件的数据是:',data);
      this.num = data;
    }
  },
  name: 'App',
  components: {
    HelloWorld,Test
  }
}
</script>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
