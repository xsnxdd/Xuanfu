<template>
  <div class="hello">
     {{ value1 }}

    <button @click="value1 = 999">修改(错误)</button>
    <button @click="test">修改(正确)</button>
    <button @click="test2">修改v-model(正确2)</button>




      <h2>仅仅针对第二个组件的测试  {{value}}</h2>


  </div>
</template>

<script>
export default {
  methods:{
    test(){
      console.log(this);
      this.$emit('getResult',999);
    },
    test2(){
      this.$emit('input',9999);
    }
  },

  name: 'HelloWorld',
  props: {
    value:Number, // v-model
    msg: String,
    value1:{
      type:Number,
      default:()=>18
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
