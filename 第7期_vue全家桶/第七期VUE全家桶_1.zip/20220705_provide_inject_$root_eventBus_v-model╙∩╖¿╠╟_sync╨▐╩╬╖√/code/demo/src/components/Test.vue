<template>
    <div>
        test组件

        {{ $attrs.text  }}

        <button @click="change">修改</button>
    </div>
</template>

<script>
export default {
    methods:{
        change(){
            this.$emit('update:text','Red');
        }
    },
    created() {
        console.log(this);
    }
}
</script>

<style>

</style>