import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

// 类似于window 一般是唯一一个根组件
new Vue({
  render: h => h(App), 
}).$mount('#app')
