<template>
  <div>
    使用全局组件 <br/>
    <ShowInfo></ShowInfo>
    <ShowInfo />


    <button @click="showEventSon" >打印事件</button>

  </div>
</template>

<script>
export default {
    methods:{
        showEventSon(){
            console.log(this);  // 组件对象
            // 触发绑定在自身listeners上的事件函数
            this.$emit('click222','哈哈哈喝喝哦哦')
        }
    }

};
</script>

<style>
</style>