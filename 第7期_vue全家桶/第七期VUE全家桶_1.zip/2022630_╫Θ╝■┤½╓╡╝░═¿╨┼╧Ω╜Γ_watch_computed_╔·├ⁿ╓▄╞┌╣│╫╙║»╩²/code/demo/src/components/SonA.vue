<template>
  <div>
    <div>子组件</div>
    <!-- {{ $attrs.title }} -->
    {{ title }}
    <button @click="show">显示</button>
    props类型约束
    {{ info }}
    默认值
    {{ msg }}
  </div>
</template>

<script>
export default {
  //   props: ["title"], // 新手或者新功能开发避免使用

  props: {
    title: {
      type: String, // 类型约束
      // 必传约束
      required: true
    },
    info: {
      type: Number,
      required:true,
    },
    msg:{
        type:String,
        default(){ // 基本数据类型, 值, 引用数据类型是函数,统一写函数
            return '欢迎光临'
        }
    }
  },

  // 父传递的,子声明了, 就作为自己的使用
  methods: {
    show() {
      console.log(this.title);
    }
  }
};
</script>

<style>
</style>