<template>
  <div>
    <div class="box" v-for="({h,d,f},index) in dataArr" :key="index">
      <!--  <slot/> 默认被填充 -->
      <slot :h="h"  name="header"></slot>
      <br />
      <slot :d="d" name="default"></slot>
      <br />
      <slot :f="f" name="footer" />
    </div>
  </div>
</template>

<script>
export default {
  props: ["dataArr"]
};
</script>

<style scoped>
.box {
  border: 1px solid grey;
  background: yellowgreen;
  height: 100px;
}
</style>