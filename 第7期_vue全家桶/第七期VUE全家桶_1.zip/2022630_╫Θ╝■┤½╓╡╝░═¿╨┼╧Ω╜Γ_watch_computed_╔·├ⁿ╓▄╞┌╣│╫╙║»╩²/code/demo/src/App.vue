<template>
  <div id="app">
    <son-a title="常量传递" :info="123"></son-a>
    <!-- SonA: 有些环境, SonA不能被识别, 颜色可以区分于原生标签div -->
    <SonA :title="text" :info="123" msg="Green帅"></SonA>

    <h2>======第二个实例.全局组件及事件========</h2>

    <!-- 测试使用全局组件 -->
    <SonB @click222="eventShow"></SonB>

    <h2>======第3个实例.传递DOM元素========</h2>
    <SonC :dataArr="arr">
      <template v-slot:header="{ h }">
        <button>传递给子组件的头部插槽 => {{h}}</button>
      </template>
      <!-- v-slot只能卸载template或者组件上 -->
      <template #default="{d}">
      <button >传递给子组件的插槽 => {{d}}</button>
      </template>

      <template #footer="{f}">
        <button>传递给子组件的底部插槽 => {{f}}</button>
      </template>
    </SonC>
  </div>
</template>

<script>
// 1. 引入(ES6 Module)
// import SonA from './components/SonA'; // 可以省略 .js .vue后缀
// 路径别名方式
import SonA from "@/components/SonA"; // @/ 指的是src下面的内容, @代表src
import SonB from "@/components/SonB";
// 插槽
import SonC from "@/components/SonC";
// 3. 使用
export default {
  methods: {
    eventShow(data) {
      console.log("数据再此:", data);
    }
  },
  data() {
    return {
      text: "变量传递",
      arr: [
        { h: "头部标题1", d: "中间标题1", f: "底部头部标题1" },
        { h: "头部标题2", d: "中间标题2", f: "底部头部标题2" }
      ]
    };
  },
  name: "App",
  // 2. 声明
  components: {
    // SonA:SonA, // 非ES6简写形式
    // key和valye都是用的同一个名字,可以简写
    SonA,
    SonB,
    SonC
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
