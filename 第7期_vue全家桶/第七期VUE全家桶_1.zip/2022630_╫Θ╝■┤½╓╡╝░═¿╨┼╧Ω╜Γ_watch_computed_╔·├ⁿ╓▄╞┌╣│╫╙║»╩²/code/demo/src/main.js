import Vue from 'vue'
import App from './App.vue'
import GlobalSonB from '@/components/GlobalSonB';
Vue.config.productionTip = false

// 全局组件   组件名称 options选项
Vue.component('ShowInfo',GlobalSonB);






new Vue({
  render: h => h(App),
}).$mount('#app')
