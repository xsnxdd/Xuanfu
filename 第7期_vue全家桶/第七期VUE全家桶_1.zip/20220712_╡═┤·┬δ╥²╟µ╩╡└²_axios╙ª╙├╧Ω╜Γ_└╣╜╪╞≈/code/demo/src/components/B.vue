<template>
  <div>
    {{ b }}
    <button @click="b--">b--</button>
  </div>
</template>

<script>
export default {
    data(){
        return {
            b:999
        }
    }
}
</script>

<style>

</style>