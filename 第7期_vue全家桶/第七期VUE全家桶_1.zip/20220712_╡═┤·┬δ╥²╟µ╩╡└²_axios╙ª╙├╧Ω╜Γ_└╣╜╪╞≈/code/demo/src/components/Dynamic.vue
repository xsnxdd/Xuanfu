
<script>
export default {
  props: ["json"],
  // jsx写法简单, 但是玩法比较单一, h函数使用复杂, 比较灵活
  // render(h){
  //     return <h1>123</h1>
  // }
  methods: {
    innerRender(node) {
      let tmpChildren = [];
      if (!Array.isArray(node.children)) {
        tmpChildren = [node.children];
      } else {
        tmpChildren = node.children.map(subNode => {
          return this.innerRender(subNode);
        });
      }

      return this.$createElement(
        node.tag,
        {
          // on:node.on, // { click:function(){}   }
          attrs: node.props
        },
        tmpChildren
      );
    }
  },
  render(h) {
    let origin = h("div", [
      h("a", { href: "http://www.baidu.com" }, "百度一下"),
      h("h1", "h1标签也能用")
    ]);

    // return this.innerRender(this.json);
    return origin;
  }
};
</script>

<style>
</style>