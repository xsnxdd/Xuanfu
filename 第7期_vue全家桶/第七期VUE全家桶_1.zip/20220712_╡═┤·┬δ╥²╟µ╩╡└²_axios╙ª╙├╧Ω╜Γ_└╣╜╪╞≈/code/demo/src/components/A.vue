<template>
  <div>
    {{ a }}
    <button @click="a++">a++</button>
  </div>
</template>

<script>
export default {
    data(){
        return {
            a:1
        }
    }
}
</script>

<style>

</style>