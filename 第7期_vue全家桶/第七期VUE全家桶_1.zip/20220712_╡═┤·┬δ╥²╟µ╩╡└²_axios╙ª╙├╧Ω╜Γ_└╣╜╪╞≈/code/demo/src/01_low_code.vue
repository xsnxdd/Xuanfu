<template>
  <div id="app">
    <!-- 动态生成,显示组件 -->
    <component :is="'A'"></component>
    <component :is="'B'"></component>
    <Dynamic :json="json1" />
    <h2>低代码平台</h2>
    <div class="wrapper">
      <div class="aside">
          <button @click="addA">添加一个A</button>
          <button @click="addB">添加一个B</button>
          <button @click="addD">添加一个Dynamic</button>

      </div>
      <div class="viewport">
          <!-- 挂载点 -->
          <div :id="item.id" v-for="item in comps" :key="item.id"></div>
          <!-- <div id="a"></div> -->
          <!-- <div id="b"></div> -->

      </div>
    </div>
  </div>
</template>

<script>
import HelloWorld from "./components/HelloWorld.vue";
import A from "./components/A";
import B from "./components/B";
import Dynamic from "./components/Dynamic.vue";
import DynamicConfigs from "./dynamicConf"; // []
import Vue from 'vue';

export default {
  data() {
    return {
      json1: DynamicConfigs[1],
      comps:[]
    };
  },
  methods:{
    addA(){
       this.comps.push({
        id:'a'
      });
      // 定时器的原因是考虑到push之后的dom已生成再处理
      setTimeout(()=>{
        new Vue({
          el:document.getElementById('a'),
          ...A,// 展开data等其他属性
          render:A.render,
        });
      },200);
    },
    addB(){
    this.comps.push({
        id:'b'
      });
      // 定时器的原因是考虑到push之后的dom已生成再处理
      setTimeout(()=>{
        new Vue({
          el:document.getElementById('b'),
          ...B,// 展开data等其他属性
          template:B.template,  // run-time 模板编译器在
        });
      },200);
    },
    addD(){
      this.comps.push({
        id:'d'
      });

      // 定时器的原因是考虑到push之后的dom已生成再处理
      setTimeout(()=>{
        new Vue({
          el:document.getElementById('d'),
          render:Dynamic.render,
          propsData:this.json1
        });
      },200);


    }
  },
  name: "App",
  components: {
    HelloWorld,
    A,
    B,
    Dynamic
  }
};
</script>

<style>
.wrapper {
  display: flex;
}
.wrapper .aside {
  width: 180px;
  height: 600px;
  background: yellowgreen;
}
.viewport {
  flex: 1;
  background: grey;
  height: 600px;
}
</style>
