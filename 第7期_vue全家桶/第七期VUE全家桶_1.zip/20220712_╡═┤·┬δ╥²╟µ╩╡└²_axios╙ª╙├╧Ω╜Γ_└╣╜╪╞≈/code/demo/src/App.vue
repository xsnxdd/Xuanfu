<template>
  <div>
    <button @click="req">基本的请求</button>
    {{ text }}
    <button @click="req2">顺序发请求</button>
    <button @click="req3">整体配置发请求</button>
    <button @click="req4">post发请求</button>
    <button @click="req5">main里面配置实例</button>
    <button @click="req6">拦截器测试1</button>
    <button @click="req7">拦截器测试2</button>
  </div>
</template>

<script>
import Axios from 'axios';
export default {
    data(){
        return {
            text:''
        }
    },
    methods:{
        req(){
            Axios.get('http://localhost:8080/1.txt')
            .then(res=>{
                console.log('res:',res);
                this.text = res.data;
            })  
            .catch(err=>{
                console.log('err:',err);
            })
        },
        req2(){
            // Axios.get('/1.txt')// 网站根
            
            // 全局生效的配置
            Axios.defaults.baseURL = 'http://localhost:8080/';
            // 顺序请求
            Axios.get('1.txt')
            .then(res=>{
                console.log('res21:',res);
                return  Axios.get('2.txt')
            })  
            .then(res2=>{
                console.log('res22:',res2);
                return  Axios.get('3.txt')
            })
            .then(res3=>{
                console.log('res23:',res3);
                
            })
        },
        req3(){
            Axios({
                method:'get',
                url:'http://localhost:8080/1.txt'
            })
            .then(res=>{
                console.log('req3:',res)
            })
        },
        req4() {
            // key=value&key2=value
             this.$ajax.post('http://localhost:8080/1.txt','x1=2&x2=3')
            // JSON
            // Axios.post('http://localhost:8080/1.txt',{a:1},{
            //     params:{
            //         q:2
            //     }
            // })
        },
        req5(){
            this.$ins1.get('1.txt',{
                headers:{
                    a:123
                }
            })
        },
        req6(){
            this.$ins2.get('http://localhost:8080/XXX.txt')
            .then(res=>{
                console.log(res,'res6');

            })
            .catch(err=>{
                console.log(err,'err6');
            })
        },
         req7(){
            this.$ins2.get('http://localhost:8080/1.txt')
            .then(res=>{
                console.log(res,'res7');

            })
            .catch(err=>{
                console.log(err,'err7');
            })
        }
    }
}
</script>

<style>

</style>