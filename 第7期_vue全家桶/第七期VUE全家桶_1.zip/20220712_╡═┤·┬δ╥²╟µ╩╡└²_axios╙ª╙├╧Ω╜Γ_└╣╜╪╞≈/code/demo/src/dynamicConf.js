export default [
    {
        tag: "div",
        children: [
            { tag: "button", children: "111百度" },
            {
                tag: "a",
                props: { href: "http://www.baidu.com" },
                children: "111百度一下, 你就知道"
            }
        ]
    },
    {
        tag: "div",
        children: [
            {
                tag: "a",
                props: { href: "http://www.baidu.com" },
                children: "百度一下, 你就知道222"
            },
            { tag: "h1", children: "百度222" }
        ]
    }
]