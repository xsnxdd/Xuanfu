import Vue from 'vue'
import App from './App.vue'
import Axios from 'axios';
Vue.config.productionTip = false

// 全局配置
Axios.defaults.baseURL = 'http://localhost:8080/';
// 全局组件的注册地
Vue.prototype.$ajax = Axios; // 组件实例

// 根据不同实例来操作(不同业务服务器)
let instance1 = Axios.create({
  baseURL:'http://www.baidu.com'
});
let instance2 = Axios.create({
  baseURL:'http://google.cn'
});

Vue.prototype.$ins1 = instance1;
Vue.prototype.$ins2 = instance2;


// 全局和实例都可以配置拦截器
// 公共行为的提取, 自动化执行
instance2.interceptors.request.use(config=>{
  // 请求之前做的事情
  // config.headers = {} // 不要覆盖请求头
  config.headers['uname'] = 'green'; 
  console.log('请求拦截器触发了')
  return config;
},err=>{
  // 请求引起的错误 
  console.log('req,error');
});
instance2.interceptors.response.use(response=>{
  console.log('响应拦截器触发了')
  return response; // { data:{},config:{}}
},error=>{
  // 通用处理请求错误
  // 超出2xx的状态码触发当前函数
  // 业务状态码判断
  if (error.response) {
    // 请求成功发出且服务器也响应了状态码，但状态代码超出了 2xx 的范围
    console.log(error.response.data);
    console.log(error.response.status); //404
    
    if (error.response.status === 404) {
      windiw.location.reload();
    }
   
    console.log(error.response.headers);
  }
  // 响应给外部,让其知道失败
  return Promise.reject(error);

})
new Vue({
  render: h => h(App),
}).$mount('#app')
