import Vue from 'vue'
import Vuex from 'vuex'
import user from './modules/user';
import order from './modules/order';

Vue.use(Vuex); //  {  install: function install (Vue) {   属性挂载 组件 指令 过滤器 } }



// 动态导入所有模块                   目录     是否子 文件特点
const modulesFn = require.context('./modules', true, /\.js$/);
const regex = /.*\/(.*)\.js$/
console.dir(modulesFn);
const modules = {};
// modulesFn.keys() 可以获取到上述满足条件的文件的加载路径
// modulesFn方法 modulesFn(路径) 获取模块
// {文件的加载路径user:模块}
modulesFn.keys().forEach(filepath => {
  console.log(filepath);
  let moduleName = regex.exec(filepath);
  if (moduleName!== null) {
    moduleName = moduleName[1]
  }
  const moduleObj = modulesFn(filepath);
    modules[moduleName] = {
      namespaced: true,
      ...moduleObj.default
    }
  // let config2 = {
  //   order: {
  //     namespaced: true,
  //     ...moduleObj.default
  //   }
  // }
})




// 应用级别 root属性
export default new Vuex.Store({
  state: {// 数据
  },
  mutations: {// 改变
  },
  actions: { // 行为
  },
  // modules: { // 封装业务的模块 = 数据 + 改变 + 行为 + 获取数据
  //   user, order
  // }
  modules
})
