import Vue from 'vue'
import App from './App.vue'
import router from './router'

Vue.config.productionTip = false

// 插件编写 注册
Vue.use({
  install(Vue){
    console.log(Vue,'获取到Vue')
  }
})


new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
