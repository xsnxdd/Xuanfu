<template>
    <div>
        这是管理页面
        <hr>
        <div class="manager-box">
            <router-view/>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>
.manager-box {
    width: 300px;
    height: 400px;
    background: yellowgreen;
    border: 1px solid grey;
}
</style>