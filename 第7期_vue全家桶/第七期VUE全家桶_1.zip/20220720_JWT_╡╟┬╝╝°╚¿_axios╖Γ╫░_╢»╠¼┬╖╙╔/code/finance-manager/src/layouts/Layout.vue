<template>
    <div>
            我是布局组件,下面是动态内容

            <router-view></router-view>
    </div>
</template> 

<script>
export default {
    name:'Layout'
}
</script>

<style>

</style>