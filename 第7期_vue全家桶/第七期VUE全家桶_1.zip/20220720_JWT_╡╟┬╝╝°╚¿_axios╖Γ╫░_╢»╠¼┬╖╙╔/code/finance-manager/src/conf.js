export const whiteUrlList = ['/login'];
export const secure = 'jindu520';