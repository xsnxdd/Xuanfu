<template>
  <div id="app">
    <MyWatch/>
    
    <hr/>

    <MyComputed/>
    <hr/>

    <MyComputed2/>

    <hr/>

    <MyComputed3/>

    <hr/>
    <MyFilter/>

    <hr/>
    <Recursion :dir="arr"/>

    <hr/>

    <LifeCycle v-if="isExist"/>

    <button @click="isExist = false">销毁最后个组件</button>
  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'

import MyWatch from './components/01_Watch'
import MyComputed from './components/02_Computed'
import MyComputed2 from './components/03_Computed2'
import MyComputed3 from './components/04_Computed3'
import MyFilter from './components/05_Filter'
import Recursion from './components/06_Recursion'
import LifeCycle from './components/07_LifeCycle'



export default {
  data(){
    return {
      isExist:true,
      arr:[
        { t:'a',
          children:[
            {t:'aa'}
          ]
        },
        { t:'b' }
      ]
    }
  },
  name: 'App',
  components: {
    MyWatch,
    MyComputed,
    MyComputed2,
    MyComputed3,
    MyFilter,
    Recursion,
    LifeCycle
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
