<template>
  <div>
    <div v-for="(item,index) in dir" :key="index">
      <span v-for="item in level" :key="item">*</span>    {{item.t}}
      <!--  最最最最重要的二步,控制结束条件,传递一致的数据 -->
      <Recursion v-if="item.children" :dir="item.children" :level="level+1" />
    </div>
  </div>
</template>

<script>
export default {
  // 最最最最重要的一步name,
  name: "Recursion",
  props: {
    dir: {
      type: Array,
    },
    level:{
        type:Number,
        default:()=>1
    }
  }
};
</script>

<style>
</style>