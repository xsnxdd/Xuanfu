<template>
   <div>
    <h2>04_computed和method的区别</h2>

    {{ calc1() }}
    {{ calc1() }}
    {{ calc1() }}

    {{ calc2 }}
    {{ calc2.res }}
    {{ calc2.msg }}
   </div>
</template>

<script>
export default {
    data(){
        return {
            n1:1,n2:2
        }
    },
    methods:{
        calc1(){
            console.log('方法执行了')
            return parseInt(this.n1) + parseInt(this.n2)

        }
    },
    computed:{
        calc2(){  
            console.log('计算属性执行了');
            return {
                res:parseInt(this.n1) + parseInt(this.n2),
                msg:'计算结果'
            }
        }
    }
}
</script>

<style>

</style>