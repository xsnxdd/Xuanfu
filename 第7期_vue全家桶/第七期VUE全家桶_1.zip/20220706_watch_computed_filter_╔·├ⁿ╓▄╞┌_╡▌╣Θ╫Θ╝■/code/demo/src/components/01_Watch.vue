<template>
  <div>
    <h2>01_watch</h2>
    <input type="text" v-model="num" />
    <input type="text" v-model="obj.num" />
    {{ obj2 }}
    <button @click="obj = {num:99}">测试改变obj</button>
    <hr />
  </div>
</template>

<script>
export default {
  // 监视数据改变后做的[行为],使用数据监视
  watch: {
    // this.xx相关的属性 this.num\
    num: {
      handler(newV, oldV) {
        // 数据变更时,触发的函数, 参数是新值,旧值
        console.log("叮咚..叮咚, 外卖来啦...");
        console.log("num数据改变了:", newV, "原值", oldV);
      },
      immediate: true // 立刻执行
    },
    obj: {
      // 监视默认是浅层的, 只对obj生效
      deep: true, // 深层, 监视对象下的属性
      handler(newV, oldV) {
        // 数据变更时,触发的函数, 参数是新值,旧值
        console.log("叮咚..叮咚, 外卖来啦...");
        console.log("obj数据改变了:", newV, "原值", oldV);
      }
    },
    // 'arr[0]':{  // 复杂路径不支持
        // handler(newV){
        //     console.log('arr[0]数据改变了',newV)
        // }
    // },
    'obj2.num':{ // 简单路径支持
        handler(newV){
            console.log('obj2.num数据改变了',newV)
        }
    }

  },
  data() {
    return {
      num: 1,
      obj: {
        num: 2
      },
      obj2:{
        num:3
      },
      arr: [{ name: "Green" }, { name: "Red" }]
    };
  }
};
</script>

<style>
</style>