<template>
  <div>
    <h2>计算属性进阶案例</h2>
            <!-- :value="checkAll" @input="val => checkAll = checkbox的布尔值 " -->
    全选<input type="checkbox" v-model="checkAll"/>

    <p v-for="(item,index) in arr" :key="index">
        <input type="checkbox" v-model="item.checkd" />
        {{ item.text }}
    </p>


  </div>
</template>

<script>
export default {
    computed:{
        checkAll:{
            // 可以指定返回什么内容,并监视
            set(val){
                this.arr.forEach(ele=>{
                    ele.checkd = val;
                })
            },
            get(){
                // 每一个都为true,返回true
               return this.arr.every(e=>e.checkd) 
            }
            // 可以指定被赋值时做什么事情
        }
    },
    data(){
        return {
            // checkAll:false,
            arr:[
                { checkd:true,text:"小木"  },
                { checkd:true,text:"小明"  },
                { checkd:false,text:"小红"  },
            ]
        }
    }
}
</script>

<style>

</style>