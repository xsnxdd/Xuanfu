<template>
  <div>
    我是生命周期组件
    <span ref="ss">{{ msg }}</span>

    <button @click="msg = 'xxx'">更改自身数据</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      msg: "hello"
    };
  },
  // 自动执行的四个
  beforeCreate() {
    console.log("beforeCreate:");
  },
  created() {
    console.log("created:");
    // 执行了注入和响应式属性之后, msg的变更会影响页面
    // this.msg = '1234';
    // 场景 发请求获取数据
  },
  beforeMount() {
    // debugger;
    console.log(this.$el);
    console.log("beforeMount:");
  },
  mounted() {
    // 初始化了$el, 因此可以获取DOM元素
    // debugger;
    console.log(this.$el);
    console.log("mounted:");
  },

  // 被动执行的
  beforeUpdate() {
    // debugger;
    console.log(this.$refs.ss);
    console.log("beforeUpdate:");
  },
  updated() {
    // debugger;
    console.log(this.$refs.ss);
    console.log("updated:");
  },
  activated() {
    console.log("activated:");
  },
  deactivated() {
    console.log("deactivated:");
  },
  beforeDestroy() {
    console.log("beforeDestroy:");
  },
  destroyed() {
    console.log("destroyed:");
  },
  errorCaptured() {
    console.log("errorCaptured:");
  }
};
</script>

<style>
</style>