<template>
  <div>
    <h2>计算属性</h2>
    <input type="text" v-model="n1" /> +
    <input type="text" v-model="n2" />
    =
    {{ res }}
  </div>
</template>

<script>
export default {
  computed: {
    // 任意的合法名称
    res() {
      // 计算 并监视 this.相关的值的改变
      // 有缓存机制
      console.log("res的计算属性触发了");
      return this.n1 - 0 + (this.n2 - 0);
    }
  },
  data() {
    return {
      n1: 0,
      n2: 0
    };
  }
};
</script>

<style>
</style>