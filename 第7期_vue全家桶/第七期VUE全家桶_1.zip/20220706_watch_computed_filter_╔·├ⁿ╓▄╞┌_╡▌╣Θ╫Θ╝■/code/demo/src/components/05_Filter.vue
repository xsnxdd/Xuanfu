<template>
  <div>
    <input type="text" v-model="text"/>

    {{ text | convert }}
    {{ text | plus }}

    <!-- 动态选择性使用 -->
    <h2>动态选择性使用</h2>
    {{ text | convert('p') }}
    <!-- 连续使用 -->
    <h2>连续使用</h2>
    {{ text | convert | plus }} 


  </div>
</template>

<script>
export default {
    filters:{
        convert(val,...args){
            if (args[0] === 'p') {
                return val + '@@@';
            } else {
                return val.split('').reverse().join('');
            }
        },
        plus(val){
            if (!val) return '';// 判断
            return val + '!!';
        }
    },
    data(){
        return {
            text:''
        }
    }
}
</script>

<style>

</style>