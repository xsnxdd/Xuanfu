import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
  errorCaptured(e) {
    console.log('errorCaptured:',e);
    return false;  // 是否继续向上通报
  }
}).$mount('#app')
