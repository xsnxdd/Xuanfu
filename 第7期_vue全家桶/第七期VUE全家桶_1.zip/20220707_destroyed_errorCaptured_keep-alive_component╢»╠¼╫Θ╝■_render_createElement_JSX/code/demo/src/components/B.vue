<template>
  <div>
    B  {{ myProp }}
    <button @click="test">测试emit父的test事件</button>
    <hr>
    <slot></slot>
    <hr>
  </div>
</template>

<script>
export default {
  props:['myProp'],
  methods:{
    test(){
      this.$emit('test');
    }
  },
 name:'B'
}
</script>

<style>

</style>