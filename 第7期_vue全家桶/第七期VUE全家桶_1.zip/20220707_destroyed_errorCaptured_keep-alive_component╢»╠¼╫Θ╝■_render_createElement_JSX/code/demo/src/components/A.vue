<template>
  <div>
    A
  </div>
</template>

<script>
export default {
  name:'A'
}
</script>

<style>

</style>