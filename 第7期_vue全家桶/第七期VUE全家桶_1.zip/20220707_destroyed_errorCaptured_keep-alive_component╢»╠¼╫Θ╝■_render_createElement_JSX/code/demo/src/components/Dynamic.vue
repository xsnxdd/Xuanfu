<script>
import B from "./B";
export default {
  props: {
    json: {
      type: Object
    }
  },
  methods:{
    showTest(){
        alert('子组件事件触发了')
    }
  },
  render(h) {
    //  createElement创建虚拟VNode对象
    // 通过接收配置属性 json, 来处理, 并实现渲染内容
    return h("div", [
      h(
        "button",
        {
          // 与 `v-bind:class` 的 API 相同，
          // 接受一个字符串、对象或字符串和对象组成的数组
          class: {
            foo: true,
            bar: false
          },
          // 与 `v-bind:style` 的 API 相同，
          // 接受一个字符串、对象，或对象组成的数组
          style: {
            color: "red",
            fontSize: "14px"
          },
          // 普通的 HTML attribute
          attrs: {
            id: "foo",
            green: "abc"
          }
        },
        "按钮1"
      ),
      h("button", "按钮2"),
      h("button", "按钮3"),
      h(B, {
        // 组件 prop
        props: {
          myProp: "bar",
        //   value:'this.xxx' 模拟v-model
        },
        on:{
            test:this.showTest,
            // input:this.showTest  模拟v-model
        },
        scopedSlots: {
            default: props => h('span', '123')
        },
      })
    ]);
  }
};
</script>

<style>
</style>