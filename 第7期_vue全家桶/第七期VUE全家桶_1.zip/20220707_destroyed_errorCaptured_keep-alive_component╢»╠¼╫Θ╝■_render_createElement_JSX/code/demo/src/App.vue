<template>
  <div>
    <!-- 加入是A-Z甚至是N多个不同的组件,v-if不好维护 -->
    <components :is="dynamicComponentName" />

    <button @click="dynamicComponentName = 'A'">切换A</button>
    <button @click="changeA">切换A组件对象</button>
    <button @click="dynamicComponentName = 'B'">切换B</button>
    <button @click="changeB">切换B组件对象</button>
    <button @click="changeCustom">切换自己创建的组件对象</button>

    <hr />

    <Dynamic :json="jsonObj" />
  </div>
</template>

<script>
import A from "@/components/A";
import B from "@/components/B";
import Dynamic from "@/components/Dynamic";
export default {
  methods: {
    changeA() {
      this.dynamicComponentName = A; // 赋值组件对象
    },
    changeB() {
      this.dynamicComponentName = B; // 赋值组件对象
    },
    changeCustom() {
      this.dynamicComponentName = {
        name: "C",
        // 不能使用template  因为是run-time
        // template:`
        //   <div>1234</div>
        // `,
        render() {
          // 在运行时环境下, 要么通过引包,处理template
          // 要么render
          // JSX: 不能使用vue的任何东西, 指令 + {{ }}
          return (
            <div>
              {this.arr.map(ele => {
                return (
                  <div>
                    <span value={123} onClick={e => (this.text = "我学懂了JS")}>
                      {this.text}
                    </span>
                    {this.text === "Green-jsx" && <h2>数据未改变,判断显示!</h2>}
                    {this.renderText()}
                  </div>
                );
              })}
            </div>
          );
        },
        methods: {
          renderText() {
            return <h2>哈哈哈哈</h2>;
          }
        },
        data() {
          return {
            text: "Green-jsx",
            arr: [1, 2, 3]
          };
        }
      };
    }
  },
  data() {
    return {
      dynamicComponentName: "B",
      jsonObj: {
        tag: "div",
        children: [
          { tag: "button", children: "111百度" },
          {
            tag: "a",
            props: { href: "http://www.baidu.com" },
            children: "111百度一下, 你就知道"
          }
        ]
      },
      jsonObj2: {
        tag: "div",
        children: [
          {
            tag: "a",
            props: { href: "http://www.baidu.com" },
            children: "百度一下, 你就知道"
          },
          { tag: "h1", children: "百度" }
        ]
      }
    };
  },
  components: {
    A,
    B,
    Dynamic
  }
};
</script>

<style>
</style>