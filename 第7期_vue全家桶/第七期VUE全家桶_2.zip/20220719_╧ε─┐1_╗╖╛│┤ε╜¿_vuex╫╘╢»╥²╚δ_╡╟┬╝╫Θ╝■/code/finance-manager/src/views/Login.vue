<template>
  <div class="login-box">
    <div class="login-input-box center">
      <h1>信贷管理系统</h1>
      <el-form
        :model="ruleForm"
        :rules="rules"
        status-icon
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
      >
        <el-input prefix-icon="el-icon-user-solid" v-model="ruleForm.username"></el-input>

        <el-input
          prefix-icon="el-icon-s-order"
          type="password"
          v-model="ruleForm.pass"
          autocomplete="off"
        ></el-input>

        <el-button type="primary" @click="submitForm">提交</el-button>
      </el-form>
    </div>
  </div>
</template>
<script>
import Axios from "axios";
import { mapMutations } from "vuex";
export default {
  data() {
    // new Error("请输入密码") // 会导致报错.....
    //
    // var validatePass = function(rule, value, callback1) {
    //   if (value === "") {
    //     let error = new Error("请输入密码");
    //     callback1(error);
    //   } else if (value.length < 6) {
    //     //     callback(new Error("密码不能小于6位数"));
    //   } else {
    //   }
    // };
    return {
      ruleForm: {
        username: "",
        pass: ""
      },
      rules: {
        pass: [
          {
            required: true,
            /*validator: validatePass,*/ trigger: "blur",
            message: "请输入密码"
          }
        ],
        username: [{ required: true, trigger: "blur", message: "请输入用户名" }]
      }
    };
  },
  methods: {
    ...mapMutations({
      changeLogin: "user/changeIsLogin",
      changeUserInfo: "user/changeUserInfo"
    }),
    // 登录方法
    async doLogin({ username, pass }) {
      // var res = await this.$ajax.post("/user/login", {
      //   account: username,
      //   password: pass
      // });

      let instance = Axios.create({
        baseURL: "/api"
      });

      // 实例也可以做拦截器的处理
      instance.interceptors.request.use(
        config => {
          const token = window.sessionStorage.getItem("token");
          if (token) {
            // 挂载到请求头中
            config.headers.token = token;
          }
          return config;
        },
        err => {}
      );
      instance.interceptors.response.use(
        response => {
          // 保存token
          const token = response?.data?.data?.token;
          console.log(response);
          if (token) {
            window.sessionStorage.setItem("token", token);
          }

          return response;
        },
        err => {}
      );

      instance
        .post("/user/login", {
          account: username,
          password: pass
        })
        .then(res => {
          console.log(res);

          if (res.data.code === 20000) {
            // 改变登录状态
            this.changeLogin(true);
            // 改变用户信息
            this.changeUserInfo({
              username: username
            });
            this.$router.push("/");
          } else {
            console.log(res);
            alert("登录失败!!!");
          }

          // getIsLogin
          // getUserInfo
          // changeIsLogin
          // changeUserInfo

          // 以备后续鉴权使用
        })
        .catch(e => {
          console.log(e);
        });
    },
    submitForm(formName) {
      this.$refs.ruleForm.validate(valid => {
        if (valid) {
          // 登录流程
          this.doLogin(this.ruleForm);
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs.ruleForm.resetFields();
    }
  }
};
</script>
<style lang="scss" scoped>
.login-input-box {
  width: 650px;
  height: 320px;
  background: #fff;
  text-align: center;
  padding: 40px 40px 12px 12px;
}
.login-box {
  height: 100%;
  background: url(../assets/bg2.jpg);
  background-size: cover;
}
.el-button {
  width: 600px;
}
.el-input {
  width: 600px;
  margin-bottom: 16px;
}
::v-deep .el-input__inner {
  background: #e5e5e5;
}
</style>