<template>
  <div id="app">
    <div id="nav">
      <router-link to="/">Home</router-link>|
      <router-link to="/about">About</router-link>

      <hr />
      <h2>嵌套路由跳转</h2>
      <router-link :to="{name:'movie'}">看电影</router-link>
      <router-link :to="{name:'music'}">听音乐</router-link>

      <h2>参数跳转</h2>
      <hr />
      <router-link :to="{ name:'query1' ,query:{ id:123 } }">具名路由查询字符串</router-link>
      <router-link :to="{ name:'params1' ,params:{ pid:998 } }">具名路由params</router-link>
      <h2>编程导航跳转</h2>
      <hr />
      <button @click="change1">编程导航1</button>
      <button @click="change2">编程导航2</button>
      <button @click="next">向后</button>
      <button @click="previous">向前</button>
    </div>
    <!-- 留坑, 1级坑 component内置组件 -->
    <router-view />
  </div>
</template>

<script>
export default {
  methods: {
    // 浏览器记录history对象不可以操作, 可以知道length
    change1() {
      // 跳转可回退的用
      this.$router.push({ name: "query1", query: { id: 666 } }); // 往队列最后放入了一个记录
    },
    change2() {
      // 跳转不可回退的用
      this.$router.replace({ name: "params1", params: { pid: 998 } }); // 往队列最后替换了一个记录
    },
    next() {
      this.$router.go(1);
    },
    previous() {
      this.$router.go(-1);
    }
  }
};
</script>

<style>
</style>
