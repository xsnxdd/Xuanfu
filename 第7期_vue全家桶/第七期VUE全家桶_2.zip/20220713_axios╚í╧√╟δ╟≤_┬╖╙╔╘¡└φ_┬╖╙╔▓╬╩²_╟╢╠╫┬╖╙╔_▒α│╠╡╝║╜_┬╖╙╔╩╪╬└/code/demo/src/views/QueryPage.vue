<template>
  <div>
    我是query
  </div>
</template>

<script>
export default {
    created(){
        let id = this.$route.query.id;
        console.log('接收到的查询字符串参数是:',id);

    }
}
</script>

<style>

</style>