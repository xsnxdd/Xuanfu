<template>
  <div class="about">
    <h1> {{msg}}</h1>
    <button @click="goback">离开</button>
  </div>
</template>

<script>
export default {
  data(){
    return {
      msg:'xxx'
    }
  },
  methods:{
    goback(){
      this.$router.go(-1);
    }
  },

   beforeRouteEnter (to, from, next) {
    // 在渲染该组件的对应路由被 confirm 前调用
    // 不！能！获取组件实例 `this`
    // 因为当守卫执行前，组件实例还没被创建
    // 但是，可以这样用
      next(vm => {
        // 通过 `vm` 访问组件实例-> 未来的组件this
          vm.msg = '数据在此';
      })
  },
  beforeRouteUpdate (to, from, next) {
    // about?id=1 和 id=2
    console.log('参数改变');
    next();
    // 触发条件见下文
    // 可以访问组件实例 `this`
  },
  beforeRouteLeave (to, from, next) {
    // 导航离开该组件的对应路由时调用
    // 可以访问组件实例 `this`
    let res =window.confirm('确认离开吗? 这么便宜, 多看看嘛')
    if (res) {
      next(); // 放行
    } else {
      next(false);
    }
  }
}
</script>