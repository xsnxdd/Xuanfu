<template>
  <div class="home">
    <button @click="req">发请求</button>
    <button @click="cancelReq">取消请求</button>
    <button @click="req1">发请求1</button>
    <button @click="cancelReq1">取消请求1</button>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from "@/components/HelloWorld.vue";
import Axios from "axios";
const CancelToken = Axios.CancelToken;
const source = CancelToken.source();

// JS中内置的 ES新提案的内容
const controller = new AbortController();

export default {
  methods: {
    req1() {
      Axios.get("/1.mp4", {
        signal: controller.signal
      }).catch(function(thrown) {
        console.log("err:", thrown);
        if (Axios.isCancel(thrown)) {
          console.log("Request canceled", thrown.message);
        } else {
          // 非取消请求的处理错误
        }
      });
    },

    req() {
      Axios.get("/1.mp4", {
        cancelToken: source.token
      }).catch(function(thrown) {
        console.log("err:", thrown);
        if (Axios.isCancel(thrown)) {
          console.log("Request canceled", thrown.message);
        } else {
          // 非取消请求的处理错误
        }
      });
    },
    cancelReq() {
      source.cancel("取消请求了");
    },
    cancelReq1() {
      controller.abort(); // 不能传递消息内容  canceled
    }
  },

  name: "Home",
  components: {
    HelloWorld
  }
};
</script>
