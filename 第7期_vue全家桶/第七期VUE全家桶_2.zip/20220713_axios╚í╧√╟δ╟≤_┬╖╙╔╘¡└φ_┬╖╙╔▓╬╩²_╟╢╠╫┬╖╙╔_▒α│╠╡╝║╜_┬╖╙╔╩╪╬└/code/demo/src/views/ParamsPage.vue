<template>
  <div>
    params传参组件
  </div>
</template>

<script>
export default {
    created(){
        let pid = this.$route.params.pid;
        console.log(pid);
    }
}
</script>

<style>

</style>