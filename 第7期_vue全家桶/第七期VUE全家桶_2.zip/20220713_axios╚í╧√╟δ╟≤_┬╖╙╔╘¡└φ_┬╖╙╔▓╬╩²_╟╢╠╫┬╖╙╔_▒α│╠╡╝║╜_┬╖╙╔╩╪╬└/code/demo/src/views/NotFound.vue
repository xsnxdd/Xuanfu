<template>
  <div>
    您访问的页面去旅行了...
  </div>
</template>

<script>
export default {
    created(){
        setTimeout(()=>{
            this.$router.replace({ name:"Home"  })
        },1000)
    }
}
</script>

<style>

</style>