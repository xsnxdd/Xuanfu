<template>
  <div>
    我是电影
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>