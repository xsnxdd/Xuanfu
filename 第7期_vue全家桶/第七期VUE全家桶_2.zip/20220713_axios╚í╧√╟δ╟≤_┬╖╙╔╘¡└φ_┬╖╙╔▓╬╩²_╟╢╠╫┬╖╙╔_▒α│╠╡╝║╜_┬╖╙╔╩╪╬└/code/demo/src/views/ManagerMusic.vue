<template>
  <div>
    我是音乐
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>