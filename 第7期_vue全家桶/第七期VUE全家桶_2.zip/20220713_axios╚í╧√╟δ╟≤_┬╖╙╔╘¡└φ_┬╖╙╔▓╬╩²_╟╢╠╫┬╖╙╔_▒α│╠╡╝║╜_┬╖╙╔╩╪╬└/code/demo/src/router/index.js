import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import QueryPage from '../views/QueryPage.vue'
import ParamsPage from '../views/ParamsPage.vue'
import NotFound from '../views/NotFound.vue'

import Manager from '../views/Manager.vue'

import ManagerMovie from '../views/ManagerMovie.vue'
import ManagerMusic from '../views/ManagerMusic.vue'

Vue.use(VueRouter);
// 安装插件: 函数内部 传递 Vue 来实现挂载原型属性,Vue.component Vue.directive 注册全局组件和指令,供开发者使用

// 重定向和404
const routes = [
  {
    path: '/index',
    redirect: {
      name: 'Home'
    }

  },

  {
    path: '/',
    name: 'Home',
    component: Home // 提前加载js
  },
  {
    path: '/about',
    name: 'About',
    meta: {
      title: '关于我'
    },
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is [[[[lazy-loaded]]]] when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    name: 'query1',
    meta: { title1: 111 },
    path: '/query1',
    component: QueryPage
  },
  {
    name: 'params1',
    path: '/params/:pid',
    component: ParamsPage
  },

  {

    path: '/manager',
    component: Manager, // 内含router-view
    children: [
      {
        name: 'movie',
        path: 'movie',
        component: ManagerMovie
      },
      {
        name: 'music',
        path: 'Music',
        component: ManagerMusic
      },

    ]


  },




  // 放最后处理404
  {
    path: '*',
    component: NotFound
  }
]

const router = new VueRouter({
  routes
})

// 最常用的全局守卫
router.beforeEach((to, from, next) => {

  console.log('to,from:', to, from)

  if (to.meta.title) {
    document.title = to.meta.title;
  }


  // next(); // 原路放行 
  // next(false) // 取消用户导航行为
  // next(路由对象或路径字符串)  跳转

  if (to.meta.title1) {  // about
    next({
      name: 'movie'
    })
  } else {
    next();
  }

}); // 每次路由切换确定组件渲染之前

// 之后, 不能控制行为了 , 路由日志
// router.afterEach((to,from)=>{}); // 每次路由切换确定组件渲染之前



export default router
