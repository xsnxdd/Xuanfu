<template>
  
    <div>
        录入申请
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>