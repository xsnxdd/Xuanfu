// import pager from './pager';
// import crud from './crud';
// export {pager,crud}

// * 是一整个模块   { default, 具名导出  }
export { default as pager } from './pager';
export { default as crud } from './crud';