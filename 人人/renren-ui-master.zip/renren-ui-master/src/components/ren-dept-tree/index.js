import RenDeptTree from './src/ren-dept-tree'

RenDeptTree.install = function (Vue) {
  Vue.component(RenDeptTree.name, RenDeptTree)
}

export default RenDeptTree
