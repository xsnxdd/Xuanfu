import RenRegionTree from './src/ren-region-tree'

RenRegionTree.install = function (Vue) {
  Vue.component(RenRegionTree.name, RenRegionTree)
}

export default RenRegionTree
