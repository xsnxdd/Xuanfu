import RenSelect from './src/ren-select'

RenSelect.install = function (Vue) {
  Vue.component(RenSelect.name, RenSelect)
}

export default RenSelect
