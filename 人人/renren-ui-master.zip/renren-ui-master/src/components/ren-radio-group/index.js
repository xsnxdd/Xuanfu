import RenRadioGroup from './src/ren-radio-group'

RenRadioGroup.install = function (Vue) {
  Vue.component(RenRadioGroup.name, RenRadioGroup)
}

export default RenRadioGroup
