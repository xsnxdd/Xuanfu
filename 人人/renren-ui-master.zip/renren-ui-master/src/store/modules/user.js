export default {
  state: {
    id: 0,
    name: '',
    superAdmin: 0
  }
}
